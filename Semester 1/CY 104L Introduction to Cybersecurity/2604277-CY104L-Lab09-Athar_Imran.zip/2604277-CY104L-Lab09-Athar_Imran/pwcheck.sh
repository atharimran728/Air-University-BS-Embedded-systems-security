
#!/bin/bash
# Name: Athar Imran
# Roll Number: 2604277
# Date: 2026-11-13
# Description: Evaluates password strength without displaying the password.

read -s -p "Enter password: " PW
echo

LENGTH=${#PW}
SCORE=0

# Check character classes
[[ "$PW" =~ [A-Z] ]] && ((SCORE++))
[[ "$PW" =~ [a-z] ]] && ((SCORE++))
[[ "$PW" =~ [0-9] ]] && ((SCORE++))
[[ "$PW" =~ [^a-zA-Z0-9] ]] && ((SCORE++))

echo "Password length: $LENGTH"
echo "Character classes matched: $SCORE/4"

# Determine password strength
if [ "$LENGTH" -ge 12 ] && [ "$SCORE" -eq 4 ]; then
    echo "Password Strength: STRONG"
elif [ "$LENGTH" -ge 8 ] && [ "$SCORE" -ge 3 ]; then
    echo "Password Strength: MEDIUM"
else
    echo "Password Strength: WEAK"
fi

unset PW
