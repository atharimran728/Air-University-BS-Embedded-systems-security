
#!/bin/bash
# Name: Athar Imrann
# Roll Number: 2604277
# Date: 2026-11-13
# Description: Audits Linux user accounts and sudo group membership.

echo "========== USER ACCOUNT AUDIT =========="

printf "%-15s %-8s %-20s %s\n" "USERNAME" "UID" "HOME" "SHELL"
echo "------------------------------------------------------------"

# List accounts with UID >= 1000
awk -F: '$3>=1000 {
    printf "%-15s %-8s %-20s %s\n", $1, $3, $6, $7
}' /etc/passwd

echo
echo "========== SUDO GROUP MEMBERS =========="

getent group sudo

echo
echo "========== AUDIT COMPLETE =========="
