
#!/bin/bash
# Name: Athar Imran
# Roll Number: 2604277
# Date: 2026-11-13
# Description: Monitors listening TCP ports and alerts on new ports.

BASELINE="/tmp/base_ports.txt"
NOW="/tmp/now_ports.txt"

# Save initial baseline
ss -tlnH | awk '{print $4}' | sort -u > "$BASELINE"

echo "========== PORT WATCHER =========="
echo "[INFO] Baseline created."
echo "[INFO] Monitoring for new listening ports..."
echo "Press Ctrl+C to stop."
echo

while true; do

    # Capture current listening ports
    ss -tlnH | awk '{print $4}' | sort -u > "$NOW"

    # Compare current ports with baseline
    NEW_PORTS=$(comm -13 "$BASELINE" "$NOW")

    if [ -n "$NEW_PORTS" ]; then
        echo "[ALERT] New listening port detected at $(date +%T)"
        echo "$NEW_PORTS"

        # Update baseline to avoid repeated alerts
        cp "$NOW" "$BASELINE"
    else
        echo "[INFO] No change - $(date +%T)"
    fi

    sleep 10

done
