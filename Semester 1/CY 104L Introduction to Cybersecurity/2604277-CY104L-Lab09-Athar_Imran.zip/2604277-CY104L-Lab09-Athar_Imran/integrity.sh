
#!/bin/bash
# Name: Athar imran
# Roll Number: 2604277
# Date: 2026-11-13
# Description: Monitors file integrity using SHA-256 hashes.

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <directory>"
    exit 1
fi

DIR="$1"
BASELINE="hashes.txt"

if [ ! -d "$DIR" ]; then
    echo "Error: Directory does not exist."
    exit 1
fi

# First execution: Create baseline
if [ ! -f "$BASELINE" ]; then
    sha256sum "$DIR"/* > "$BASELINE"
    echo "[BASELINE] Hashes created successfully."
    echo "Saved in $BASELINE"
    exit 0
fi

# Later executions: Verify integrity
echo "========== INTEGRITY CHECK =========="

RESULT=$(sha256sum -c "$BASELINE" 2>/dev/null)

echo "$RESULT" | grep ' OK$' | while read -r LINE; do
    echo "[OK] $LINE"
done

echo "$RESULT" | grep ' FAILED$' | while read -r LINE; do
    echo "[MODIFIED] $LINE"
done

if echo "$RESULT" | grep -q 'FAILED'; then
    echo "Result: File integrity compromised."
else
    echo "Result: No modifications detected."
fi
