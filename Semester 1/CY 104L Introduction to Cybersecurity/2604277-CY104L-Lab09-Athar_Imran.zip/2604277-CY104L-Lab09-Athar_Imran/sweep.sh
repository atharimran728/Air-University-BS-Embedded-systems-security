
#!/bin/bash
# Name: Athar Imran
# Roll Number: 2604277
# Date: 2026-11-13
# Description: Performs an ICMP ping sweep and saves live hosts.

# Check arguments
if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <network_prefix> <start_host> <end_host>"
    exit 1
fi

PREFIX="$1"
START="$2"
END="$3"

# Validate host numbers
if ! [[ "$START" =~ ^[0-9]+$ && "$END" =~ ^[0-9]+$ ]] ||
   [ "$START" -lt 1 ] || [ "$END" -gt 254 ] ||
   [ "$START" -gt "$END" ]; then
    echo "Error: Invalid host range."
    exit 1
fi

# Clear previous results
> live_hosts.txt

COUNT=0

echo "Starting Ping Sweep: $PREFIX.$START - $PREFIX.$END"

for i in $(seq "$START" "$END"); do
    IP="$PREFIX.$i"

    if ping -c1 -W1 "$IP" > /dev/null 2>&1; then
        echo "[UP] $IP"
        echo "$IP" >> live_hosts.txt
        ((COUNT++))
    fi
done

echo "----------------------------"
echo "Total live hosts: $COUNT"
echo "Results saved in live_hosts.txt"
